//
//  Article.swift
//  FavoriteRSSReader
//
//  Created by TangZekun on 6/22/16.
//  Copyright © 2016 TangZekun. All rights reserved.
//

import Foundation

struct Article
{
    var title = ""
    var imageUrl = ""
    var url = ""
}