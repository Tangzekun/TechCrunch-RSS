//
//  SavedCell.swift
//  FavoriteRSSReader
//
//  Created by TangZekun on 6/23/16.
//  Copyright © 2016 TangZekun. All rights reserved.
//

import UIKit

class SavedCell: UITableViewCell {
    
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var label2: UILabel!
    @IBAction func hearButtonPress2(sender: AnyObject) {
    }
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
